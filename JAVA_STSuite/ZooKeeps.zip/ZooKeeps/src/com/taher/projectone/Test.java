package com.taher.projectone;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Gorilla kong = new Gorilla();
		kong.throwSomething();
		kong.throwSomething();
		kong.throwSomething();

		kong.eatBananas();
		kong.eatBananas();
		
		kong.climb();

		System.out.println("Energy left: " + kong.showEnergyLevel());
	}

}
