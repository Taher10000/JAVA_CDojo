public class Test{
    public static void main(String[] args){
        System.out.println("My name is Tiger \nI am 23 years old \nmy hometown is NYC, NY");
    }
}